from starkware.solidity.utils import load_nearby_contract

MockStarknetMessaging = load_nearby_contract("MockStarknetMessaging")
